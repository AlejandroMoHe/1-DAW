import random
num = 0
while num != num-1:
    for i in random.randint(1, 10):
        num = i
        if num == i-1:
            break