hora = int(input("¿Qué hora es? (Usa el formato 24h): "))
minutos = int(input("¿Qué minuto es: ?"))
alarma = int(input(f"Perfecto son las {hora}:{minutos}. ¿En cuantos minutos quieres poner la alarma?"))
print(f"La alarma sonara a las  ")
