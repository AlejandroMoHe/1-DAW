# 🎮 Animatrónicos - Five Nights at Freddy's 1

Conoce a los animatrónicos principales del primer juego de FNaF.

---

## Freddy Fazbear

![Freddy Fazbear](https://www.pngkit.com/png/detail/618-6182207_artwork-freddy-fazbear-five-nights-at-freddys.png)

El líder de la banda. Freddy se vuelve más activo en las noches más avanzadas y ataca por el lado derecho.

## Bonnie

![Bonnie](https://s.pngkit.com/png/small/158-1584535_good-news-i-can-use-my-tablet-in.png)

El conejo morado, muy activo desde la primera noche. Ataca por el lado izquierdo.

## Chica

![Chica](https://s.pngkit.com/png/small/931-9317975_fnaf-chica-png-chica-1-fnaf.png)

La gallina amarilla que sostiene un cupcake. Suele atacar por el lado derecho.

## Foxy

![Foxy](https://s.pngkit.com/png/small/27-272431_imagefoxy-has-a-pirate-hat-now-fnaf-1.png)

El zorro que se esconde en Pirate Cove. Corre hacia tu puerta si no lo vigilas con frecuencia.

## ✨ Golden Freddy

![Golden Freddy](https://www.pngkit.com/png/detail/349-3493017_golden-freddy-five-nights-at-freddys.png)

Una aparición misteriosa que puede colapsar el juego si no se actúa rápido. Aparece de forma aleatoria tras ciertos eventos.

---

*Página hecha con HTML puro | FNaF © Scott Cawthon*
